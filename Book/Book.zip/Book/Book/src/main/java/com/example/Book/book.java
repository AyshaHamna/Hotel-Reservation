/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.Book;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author User
 */
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)
public class book
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    
@Column(name = "first_Name")    
private String firstName;

@Column(name = "last_Name")
private String lastName; 

@Column(name = "Email")
private String email;

@Column(name = "phone_Number")
private String phoneNumber;

@Column(name = "Room_Type")
private String RoomType; 

@Column(name = "From_Date")
private String FromDate; 

@Column(name = "To_Date")
private String ToDate;

@Column(name = "Amount")
private Float amount;

@Column(name = "Confirm_Number")
private String ConfirmNumber;

@Column(name = "book_Reference_Id")
private String bookReferenceId;

@Column(name = "Reception_Referenc_eId")
private String ReceptionReferenceId;

    public Integer getId() {
        return Id;
    }

    public void setId(Integer Id) {
        this.Id = Id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRoomType() {
        return RoomType;
    }

    public void setRoomType(String RoomType) {
        this.RoomType = RoomType;
    }

    public String getFromDate() {
        return FromDate;
    }

    public void setFromDate(String FromDate) {
        this.FromDate = FromDate;
    }

    public String getToDate() {
        return ToDate;
    }

    public void setToDate(String ToDate) {
        this.ToDate = ToDate;
    }

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public String getConfirmNumber() {
        return ConfirmNumber;
    }

    public void setConfirmNumber(String ConfirmNumber) {
        this.ConfirmNumber = ConfirmNumber;
    }

    public String getBookReferenceId() {
        return bookReferenceId;
    }

    public void setBookReferenceId(String bookReferenceId) {
        this.bookReferenceId = bookReferenceId;
    }

    public String getReceptionReferenceId() {
        return ReceptionReferenceId;
    }

    public void setReceptionReferenceId(String ReceptionReferenceId) {
        this.ReceptionReferenceId = ReceptionReferenceId;
    }

    
    
    
}
